
<template>
  <!--左侧登录div-->
  <div class="main-nav-wrapper sidenav">
      <div class="user-box clearfix">
          <img class="portrait" src="../resources/images/lion_logo2.png" alt="">
          <div class="user_name tc mb20">用户名</div>
          <div class="ys_function tc">
              <a href="javascript:;">房源列表</a>
              <a href="javascript:;">房源信息采集</a>
              <a href="javascript:;">待办任务</a>
          </div>
      </div>
      <a href="javascript:;" class="log_out_btn">退出登录</a>
  </div>

</template>

<script>
export default {
}
</script>
